#include "Kalkulator.h"

using namespace System;
using namespace System::Windows::Forms;

[STAThreadAttribute]

int main(array<System::String ^> ^args) {
	Application::EnableVisualStyles();
	Application::SetCompatibleTextRenderingDefault(false);
	KalkulatorDeluxe::Kalkulator window;
	Application::Run(%window);
	return 0;

}